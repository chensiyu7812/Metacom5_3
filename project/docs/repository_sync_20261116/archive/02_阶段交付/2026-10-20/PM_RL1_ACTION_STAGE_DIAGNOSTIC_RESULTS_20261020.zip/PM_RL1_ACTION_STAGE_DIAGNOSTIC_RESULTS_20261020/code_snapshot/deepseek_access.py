"""Scoped official-account access and money guards; no scorer or prompt changes."""
import contextlib
import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path
from decimal import Decimal
import selection as s

ENV_PATH=Path('/home/tokkio/metacom5_3.env')

def read_key(path=ENV_PATH):
    matches=[]
    for line in path.read_text().splitlines():
        match=re.match(r'^\s*(?:export\s+)?DEEPSEEK_API_KEY\s*=\s*(.*?)\s*$',line)
        if not match:continue
        value=match.group(1)
        if value.startswith(('"',"'")):
            quote=value[0];end=value.find(quote,1)
            if end<0 or value[end+1:].strip() and not value[end+1:].strip().startswith('#'):
                raise ValueError('invalid quoted credential assignment')
            value=value[1:end]
        else:value=re.split(r'\s+#',value,maxsplit=1)[0].strip()
        if not value or not re.fullmatch(r'[A-Za-z0-9_.-]+',value):
            raise ValueError('empty or nonliteral credential; no evaluation/interpolation')
        matches.append(value)
    if len(matches)!=1:raise ValueError('expected exactly one configured DEEPSEEK_API_KEY')
    return matches[0]

@contextlib.contextmanager
def credential_scope(key):
    # The existing stdlib transport reads this process environment. Disable all
    # proxy sources for its lifetime; restore on exit, never write config files.
    names=['DEEPSEEK_API_KEY']+[k for k in os.environ if k.lower().endswith('_proxy')]
    before={k:os.environ.get(k) for k in names}
    for k in names:os.environ.pop(k,None)
    os.environ['DEEPSEEK_API_KEY']=key
    try:yield
    finally:
        for k in names:os.environ.pop(k,None)
        for k,v in before.items():
            if v is not None:os.environ[k]=v

def management_once(out,name,key):
    if name not in ('models','user/balance'):raise ValueError('unapproved management route')
    stem=name.replace('/','_');start=time.monotonic()
    s.save(out/(stem+'.started.json'),dict(method='GET',endpoint='https://api.deepseek.com/'+name,
        started_unix=time.time(),research_payload=False,scoring_attempt=False,retries=0))
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect)
    request=urllib.request.Request('https://api.deepseek.com/'+name,headers={'Authorization':'Bearer '+key,'Accept':'application/json'})
    result={'method':'GET','route':name,'elapsed_seconds':None}
    try:
        with opener.open(request,timeout=30) as response:
            data=json.loads(response.read())
            result.update(status=response.status,body=data,response_headers={k:v for k,v in response.headers.items()
                if k.lower() in ('date','x-request-id','request-id')})
    except Exception as exc:
        result.update(status=getattr(exc,'code',None),error_type=type(exc).__name__,
            error='management request failed; credential-bearing exception details not recorded')
    result['elapsed_seconds']=time.monotonic()-start
    s.save(out/(stem+'.result.json'),result)
    return result

class AccountBudget(s.Budget):
    def __init__(self,*args,account_available_usd,**kwargs):
        super().__init__(*args,**kwargs)
        self.account_available=s.nanodollars(account_available_usd)

    def reserve(self,reservation_id,amount,binding):
        # Local pool lock serializes this stage. Existing inherited shared locks
        # and the explicit legacy-writer lock protect the shared money history.
        with self.locked():
            _,trial,_,_=self._totals(self.events())
            if trial+amount>self.account_available:raise ValueError('verified opening account funds cannot cover next liability')
        return super().reserve(reservation_id,amount,binding)

def cost_from_usage(raw):
    """No usage -> retain full reserve. Known usage -> peak conservative charge.

    Exact off-peak estimate is separate from shared ledger upper accounting;
    we do not claim provider billing reconciliation from a token calculation.
    """
    from adapters import billed_peak_nanodollars
    upper=billed_peak_nanodollars(raw)
    if upper is None:return dict(accounted_upper_nanodollars=None,usage_price_estimate_usd=None,invoice_confirmed=False)
    u=raw['usage'];n=u['prompt_tokens'];hit=u.get('prompt_cache_hit_tokens');miss=u.get('prompt_cache_miss_tokens')
    split_valid=type(hit)is int and type(miss)is int and min(hit,miss)>=0 and hit+miss==n
    # All current runs start away from UTC peak boundaries. Detect rather than
    # assume; no holiday discount is needed for all-hours off-peak intervals.
    from datetime import datetime,timezone
    start=raw['request_started_unix'];end=start+raw['total_seconds']
    def off(t):
        x=datetime.fromtimestamp(t,timezone.utc)
        return x.weekday()>=5 or not(1<=x.hour<4 or 6<=x.hour<10)
    offpeak=off(start) and off(end) and end-start<900.5
    factor=Decimal('0.5') if offpeak else Decimal(1)
    base=Decimal(hit)*6+Decimal(miss)*300 if split_valid else Decimal(n)*300
    estimate=(base+Decimal(u['completion_tokens'])*1200)*factor/Decimal(10**9)
    return dict(accounted_upper_nanodollars=upper,accounted_upper_usd=s.usd(upper),
        usage_price_estimate_usd=str(estimate),cache_split_complete=split_valid,
        usage_price_estimate_cny=str(estimate/Decimal('0.15')),
        observed_off_peak_interval=offpeak,invoice_confirmed=False,
        explanation='shared ledger uses all-input cache-miss peak upper; observed usage estimate separately priced; reasoning subset not added twice')

def visible_paid_writers():
    suspects=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name)==os.getpid():continue
        try:
            parts=(p/'cmdline').read_bytes().split(b'\0');comm=(p/'comm').read_text().strip()
            if not any(x in comm.lower() for x in ('python','curl','wget')):continue
            # Never persist arbitrary command lines or environment variables.
            scripts=[Path(x.decode(errors='replace')).name for x in parts[1:] if x.endswith(b'.py')]
            paid=any(any(k in x.lower() for k in ('api','acceptance_batch','teacher_qualification','continue_v1','selection.py')) for x in scripts)
            paid=paid or any(b'api.deepseek.com' in x or b'generativelanguage.googleapis.com' in x for x in parts)
            if paid:suspects.append(dict(pid=int(p.name),comm=comm,scripts=scripts))
        except (PermissionError,FileNotFoundError,ProcessLookupError):continue
    return suspects

def execute_official_stage(c,development=False):
    import fcntl
    from adapters import DeepSeekTransport
    package=s.HERE/('D_development_20261015' if development else 'CD_engineering_20261015');root=s.HERE/'live_runs'
    plan=s.load_plan();p=s.read(package/'protocol.json');auth=s.read(package/'continuation_authorization.json')
    if p!=c.protocol(plan,api_engineering=True,api_development=development):raise ValueError('API protocol/code drift')
    ledger=s.REPO/'project/outputs/paper1_api_budget/cumulative_paid_api_budget.jsonl'
    opening=s.read(package/'initial_ledger_and_processes.json');original_bytes=ledger.read_bytes()
    if s.sha(ledger)!=opening['sha256']:raise ValueError('shared ledger changed before CD start; reconcile first')
    balance=s.read(package/'user_balance.result.json');models=s.read(s.HERE/'CD_engineering_20261015/models.result.json')
    if balance['status']!=200 or not balance['body'].get('is_available'):raise ValueError('account unavailable')
    model=next((x for x in models.get('body',{}).get('data',[]) if x.get('id')=='deepseek-flash'),{})
    if (model.get('name'),model.get('context_window'),model.get('max_output_tokens'))!=('DeepSeek-V4.1-Flash',1048576,393216):raise ValueError('official capabilities drift')
    amounts={x['currency']:Decimal(x['total_balance']) for x in balance['body']['balance_infos']}
    # Two official tariff tables have the identical ratio 0.15 USD per CNY for
    # each token type. This is tariff-equivalent purchasing capacity, NOT FX.
    available=amounts.get('USD',Decimal(0))+amounts.get('CNY',Decimal(0))*Decimal('0.15')
    financial_trial=p.get('financial_trial_identity',p['identity'])
    # Current balance is already net of past charges. Comparing the ENTIRE trial
    # against it is intentionally conservative; it cannot reset the USD2 cap.
    budget=AccountBudget(ledger,trial=financial_trial,trial_cap=s.nanodollars(2),shared_cap=s.nanodollars(20),
        baseline=s.nanodollars('1.50724291'),opening=s.nanodollars('0.03079930'),
        external_liability=0,account_available_usd=str(available))
    def guard():
        if not ledger.read_bytes().startswith(original_bytes):raise ValueError('shared ledger prefix changed')
        extra=ledger.read_bytes()[len(original_bytes):].decode().splitlines()
        if any(json.loads(x).get('selection_trial')!=financial_trial for x in extra):raise ValueError('concurrent foreign paid writer changed shared ledger')
        if visible_paid_writers():raise ValueError('visible concurrent paid writer; do not operate on it')
    def preflight():
        guard();history=c.reconstruct(plan,p,root)
        if history['cumulative_calls']!=(107 if development else 99):raise ValueError('unexpected actual cumulative before this stage')
        total,_,reserved,settled=budget._totals(budget.events())
        if set(reserved)-set(settled):raise ValueError('unreconciled opening liabilities')
        if development:
            ref=p['prior_service_identity']
            if s.sha(ref['path'])!=ref['sha256']:raise ValueError('prior service identity changed')
            s.save(out/'service_identity.json',s.read(ref['path']))
            s.save(out/'service_identity_inheritance.json',ref)
        checks=[]
        for req in p['requests']:
            orig=next(x for x in plan['requests'] if x['request_id']==req['original_slot_request_id'])
            messages,schema=s.payload(plan,orig)
            from adapters import api_body
            body=api_body(p['configs'][req['candidate']],messages)
            assert set(body)==({'model','messages','thinking','response_format','max_tokens','stream','stream_options','temperature'}
                if req['candidate']==s.CANDIDATES[2] else {'model','messages','thinking','response_format','max_tokens','stream','stream_options','reasoning_effort','top_p'})
            checks.append(dict(original_slot=orig['request_id'],request_id=req['request_id'],messages_identity=s.digest(messages),
                schema_identity=s.digest(schema),wire_body_identity=s.digest(body),wire_body_utf8_bytes=len(s.canonical(body).encode()),
                full_input_unchanged=True,client_truncation=False))
        s.save(out/'necessary_preflight.json',dict(history=history,account_balance_currencies={k:str(v) for k,v in amounts.items()},
            account_tariff_equivalent_usd=str(available),account_currency_conversion='official tariff ratio, not FX',
            shared_accounted_usd=s.usd(total),known_unsettled_count=0,visible_paid_writers=[],checks=checks,
            official_model=model,local_GPU_used=False,external_liabilities='no known submitted batch or active paid writer in reconciled local records'))
    class Observed(DeepSeekTransport):
        def gpu_condition(self):guard()  # Existing dispatch hook; no GPU query or load.
    def review(req,orig,response):
        path=out/(req['request_id']+'.review.json');start=time.monotonic()
        print(s.canonical(dict(awaiting_source_review=str(path),request_id=req['request_id'],item=orig['item_key'])),flush=True)
        while not path.exists():
            if time.monotonic()-start>600:raise TimeoutError('source review not supplied; stop configuration')
            time.sleep(1)
        return s.read(path)
    out=root/p['output_subdir']/'stage'
    with (root/'.pool.lock').open('a') as pool_lock,ledger.with_suffix('.lock').open('a') as legacy_lock:
        fcntl.flock(pool_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        fcntl.flock(legacy_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        out.mkdir(parents=True,exist_ok=False)
        key=read_key()
        with credential_scope(key):
            answer=c.run(plan,p,auth,root,out,mode='live',preflight=preflight,wait_idle=None,
                transport_factory=Observed,review_fn=review,budget=budget)
        del key
        total,trial,reserved,settled=budget._totals(budget.events())
        s.save(out/'financial_closeout.json',dict(shared_accounted_upper_usd=s.usd(total),trial_accounted_upper_usd=s.usd(trial),
            unresolved_reservations=[v for k,v in reserved.items() if k not in settled],
            ledger_sha256=s.sha(ledger),prior_ledger_prefix_unchanged=ledger.read_bytes().startswith(original_bytes)))
        print(s.canonical(dict(cumulative=answer['history_after']['cumulative_calls'],blocked=answer['blocked'],
            trial_accounted_upper_usd=s.usd(trial))),flush=True)
